README/LIESMICH

########################################################################
Filename: Sorbets Skybox Pack
Filesize: 16,5 MB
Fileped by: Sorbet
Game: Elite Force 1.2 + XP
########################################################################
Installation instructions - extract the .pk3 file to your gamedir/baseef/env folder.
########################################################################
File INFO:
(GERMAN)
Diesmal habe ich ein Skybox Pack zusammengestellt. Es befinden sich 30. Skyboxen
im RAR File. Eine unbearbeitete *.shader datei, damit ihr sie auch einf�gen k�nnt.
Wobei ich davon ausgehe das ihr wisst, wie! Ansonsten nachfragen... 
(ENGLISH)
This time I put together a skybox pack. There are 30 skyboxes
in this RAR file and an unedited *.shader file so you can insert it, assuming you know how.
If not feel free to ask...
########################################################################
CONTACT:
MSN: spacegyver@hotmail.com 
E-Mail: spacegyver@hotmail.com
########################################################################
Special Links:
>>> www.ef-world.de
>> www.planetsmc.de
> www.fun4gamers.com
########################################################################

BYE BYE  Sorbet